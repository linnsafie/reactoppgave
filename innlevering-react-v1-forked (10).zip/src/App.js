import React, { useState } from 'react';
import MyComponent from './components/MyComponent';
import Wrapper from './components/Wrapper';
import Alert from './components/Alert';
import Title from './components/Title';
import './styles.scss';


const App = () => {

  const [inputFromChild, setInputFromChild] = useState('')
  
  return (
    <>
 <MyComponent/>
<Food
        array={[
          { id: 1, name: 'Pizza' },
          { id: 2, name: 'Hamburger' },
          { id: 3, name: 'Coke' }
        ]}
      />
      <Title/>
      <Wrapper name="wrap">
        <p>Child en</p>
        <p>Child to</p>
      </Wrapper>

      <button onClick={handleClick}>Knapp</button>

      <Alert typing="Typing"
       inputFromChild = {inputFromChild}
       setInputFromChild = {setInputFromChild}/>
      <p>{inputFromChild}</p>

    </>
  );
};

  function handleClick () {
    console.log("Clicked",);
  };

  
function Food({ array }) {
  return (
    <>
      <ul>
        {array.map((array) => (
          <li key={array.id}>{array.name}</li>
        ))}
      </ul>
      
    </>
  );
}

function MyControlledInput() {
  const [value, setValue] = useState("");

  const onChange = (event) => {
    setValue(event.target.value);
    console.log("change")

  };

  return (
    <>
      <div>Her kommer input: {value}</div>
      <input placeholder="Skriv verdien" value={value} onChange={onChange} />
    </>
  );
}

function submit(){
  console.log("funker");
  
}
export default App;

/*return (
  <>
    <MyComponent value="It Works!" />
  </>
);
 */