import React from 'react';

const Food = ({ food }) => {
  const items = food;
  return (
    <ul>
      {array.map((items, index)) => (
        <ListItem key={index} value={items} />
      ))}
      </ul>
  );
};

ReactDOM.render(
  element,
  document.getElementById('Food')
);

