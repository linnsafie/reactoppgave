import React, { useState } from 'react';

/*const Alert = ({ Typing }) => {
  const [BoxContent, AddLetter] = useState('');
  const ButtonClicked = (props) => {
    console.log('Clicked');
    alert(BoxContent);
    return (document.querySelector('p').innerHTML = BoxContent);
  };

  function HandleKey(e) {
    const key = e.key;
    AddLetter((p) => p + key);
  }

  function button(){
    <button onClick={handleClick}>Knapp</button>
  }

  return (
    <>
      <button onClick={ButtonClicked}>Trykk her</button>
      <input onChange={Typing} autoFocus onKeyUp={HandleKey} />
      <p>BoxContent: {BoxContent} </p>
    </>
  );
}
*/

const Alert =({setInputFromChild}) => {
  
const [value, setValue] = useState(); {
  function submit () {
    console.log("Clicked",);
    setInputFromChild(value);
  
  };

  const inputChange = (event) => {
    setValue(event.currentTarget.value);
    console.log("change")

  };

  return (
    <>
    <p> BoxContent: {value} </p>
<input defaultValue={value} onChange={inputChange}/>
<button onClick={submit}>Send</button>

  </>
  );
};
}

export default Alert;
