import React from 'react';

/*const MyComponent = () => {
  return <h1>My First Component</h1>;
};
*/
function MyComponent({title }) {
  return <h1> It Works {title} </h1>;
}
export default MyComponent;

/*ReactDOM.render(
  element,
  document.getElementById('MyComponent')
);
*/