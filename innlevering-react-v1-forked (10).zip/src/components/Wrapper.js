import React from 'react';
function Wrapper({ children }) {
  return <>
<section className="flex">{children}</section>
</>;
}

 export default Wrapper