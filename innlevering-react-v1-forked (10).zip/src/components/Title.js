import React from 'react';

function Title({title }) {
  return <h1> It Works title comp{title} </h1>;
}

export default Title